# PLOG - Proj2

### Grupo: Gold Star_2, Turma 5

4 de janeiro de 2021  

| Nome 			              |  Email instituicional |					   
| ----------------------------------- | ----------------------| 
| Luís Filipe Sousa Teixeira Recharte | up201806743@fe.up.pt  |
| Rita Matos Maranhão Peixoto         | up201806257@fe.up.pt  |



## Instruções de execução

O programa deve ser corrido em SICStus 4.6.

Tendo como Working Directory src, deve fazer Consult do ficheiro analysis.pl e após o comando terminar, escrever na consola 'run_star(+Predicado,+Dimensão,+Restrito).', se desejar ver o output na consola ou 'save(+Predicado,+Ficheiro,+Dimensão, +Restrito)', se desejar guardar as soluções num ficheiro.
